package berkarya.kopas.id.quiz.util;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import berkarya.kopas.id.quiz.R;

public class Activity1 extends AppCompatActivity{

    static TabLayout tabs;
    static ViewPager pages;
    DrawerLayout drawer;
    private ArrayList<MengerjakanSoal> mengerjakanSoal;
    private static ArrayList<BankSoal> bankSoal;
    private RecyclerView mRecyclerView;
    TextView waktu;
    viewPageAdapter adapter;
    static TextView nomor;

    private static Menu menu;

    static String audioFileUrl = "";
    private AudioServiceBinder audioServiceBinder = null;

    private Handler audioProgressUpdateHandler = null;

    // Show played audio progress.
    private ProgressBar backgroundAudioProgress;

    // This service connection object is the bridge between activity and background service.
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            // Cast and assign background service's onBind method returned iBander object.
            audioServiceBinder = (AudioServiceBinder) iBinder;
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lyt_activity);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);

        tabs = findViewById(R.id.tabs);
        pages = findViewById(R.id.viewPager);

        getBankSoal();

        tabs.setupWithViewPager(pages);
        setUpViewPager(pages,bankSoal);

        // enable pull down to refresh
        final SwipeRefreshLayout mSwipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        final ProgressBar progressBar = findViewById(R.id.progressBar);

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {


                progressBar.setVisibility(View.VISIBLE);
                // do something
                getBankSoal();
                adapter.notifyDataSetChanged();

                // after refresh is done, remember to call the following code
                if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                    mSwipeRefreshLayout.setRefreshing(false);  // This hides the spinner
                    progressBar.setVisibility(View.GONE);
                }
            }
        });

        nomor = toolbar.findViewById(R.id.toolbarNomor);
        waktu = toolbar.findViewById(R.id.toolbarWaktu);
        nomor.setText( String.valueOf(tabs.getSelectedTabPosition()+1) );
        new TimerClass(60000 * 60, 1000).start();

        /*View headerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.tab, null, false);

        TextView linearLayoutOne = (TextView) headerView.findViewById(R.id.nomor);

        int tabCount = tabs.getTabCount();
        for (int i = 0; i < tabCount; i++) {
            TabLayout.Tab tab = tabs.getTabAt(i);
            tab.setCustomView(linearLayoutOne);
            tab.setText(i);
        }*/

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        toggle.setDrawerIndicatorEnabled(false);
        drawer.addDrawerListener(toggle);

        toggle.syncState();

        addDummyData();
        mRecyclerView = (RecyclerView) findViewById(R.id.drawerRecyclerView);
        final DrawerAdapter adapter = new DrawerAdapter(mengerjakanSoal);
        final GridLayoutManager manager = new GridLayoutManager(this, 4);
        manager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                return position == 0 ? 4 : 1;
            }
        });

        mRecyclerView.setLayoutManager(manager);
        mRecyclerView.setAdapter(adapter);

        adapter.setOnItemClickLister(new DrawerAdapter.OnItemSelecteListener() {
            @Override
            public void onItemSelected(View v, int position) {

                //TODO change if the position has changed
                Toast.makeText(Activity1.this, "You clicked at position: "+ position, Toast.LENGTH_SHORT).show();

                if( position == 0 ) {
                    //
                }else{
                    TabLayout.Tab tab = tabs.getTabAt(position - 1);
                    tab.select();
                }

                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.END);
            }
        });
/*
        for(int x = 1; x<=40; x++) {
            View headerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                    .inflate(R.layout.tab, null, false);
            LinearLayout linearLayoutOne = (LinearLayout) headerView.findViewById(R.id.linearlayoutItem);
            TextView tabNomor = (TextView) headerView.findViewById(R.id.tabNomor);

            tabNomor.setText( String.valueOf(x) );
            tabs.getTabAt(x-1).setCustomView(linearLayoutOne);
        }*/


/*
        final CheckBox ragu_ragu = findViewById(R.id.btn_belum_terjawab);
        final ImageView prev = findViewById(R.id.btnPrev);
        final ImageView next = findViewById(R.id.btnNext);

        ragu_ragu.setChecked(false);
        if( pages.getCurrentItem() == 0 ){
            prev.setVisibility(View.GONE);
            next.setVisibility(View.VISIBLE);
        }else if( pages.getCurrentItem() == bankSoal.size()-1 ){
            prev.setVisibility(View.VISIBLE);
            next.setVisibility(View.GONE);
        }else{
            prev.setVisibility(View.VISIBLE);
            next.setVisibility(View.VISIBLE);
        }*/


        /*
        prev.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                pages.setCurrentItem(pages.getCurrentItem()-1, true); //getItem(-1) for previous
            }
        });
        next.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                pages.setCurrentItem(pages.getCurrentItem()+1, true); //getItem(-1) for previous
            }
        });*/

        /*
         * Perbesar Suara Max
         */
        AudioManager audio = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);

        //mediaPlayer.setOnCompletionListener(mCompletionListener);

        // Bind background audio service when activity is created.
        bindAudioService();

        backgroundAudioProgress = (ProgressBar)findViewById(R.id.play_audio_in_background_service_progressbar);

    }



    private void getBankSoal() {
        bankSoal = new ArrayList<>();

        for(int z = 1; z<=40; z++) {


            String soal_gambar = "<img style=\"width:100%;\" src=\"https://www.murrayc.com/blog/wp-content/uploads/2014/10/screenshot_toolbar_dark_text_on_light_with_dark_theme_with_menu_cropped-300x136.png\"/><br/>"+
                    "Berdasarkan gambar mutasi yang terjadi adalah";
            if(z > 3){
                soal_gambar = "";
            }

            String soal_audio = "";
            if( z == 4 ){
                soal_audio = "http://www.dev2qa.com/demo/media/test.mp3";
            }

            bankSoal.add(new BankSoal(
                    String.valueOf(z),
                    z+" - Perhatikan gambar skema mutasi berikut ini<br/>"+soal_gambar,
                    soal_audio,
                    "Crossing over dan delesi",
                    "Delesi dan translokasi",
                    "Duplikasi dan katenasi",
                    "Delesi dan duplikasi",
                    "Katenasi dan delesi"
            ));
        }
    }

    // Bind background service with caller activity. Then this activity can use
    // background service's AudioServiceBinder instance to invoke related methods.
    private void bindAudioService()
    {
        if(audioServiceBinder == null) {
            Intent intent = new Intent(Activity1.this, AudioService.class);

            // Below code will invoke serviceConnection's onServiceConnected method.
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
        }
    }

    // Unbound background audio service with caller activity.
    private void unBoundAudioService()
    {
        if(audioServiceBinder != null) {
            unbindService(serviceConnection);
        }
    }

    // Create audio player progressbar updater.
    // This updater is used to update progressbar to reflect audio play process.
    private void createAudioProgressbarUpdater()
    {
        /* Initialize audio progress handler. */
        if(audioProgressUpdateHandler==null) {
            audioProgressUpdateHandler = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    // The update process message is sent from AudioServiceBinder class's thread object.
                    if (msg.what == audioServiceBinder.UPDATE_AUDIO_PROGRESS_BAR) {

                        if( audioServiceBinder != null) {
                            // Calculate the percentage.
                            //int currProgress =audioServiceBinder.getAudioProgress();


                            backgroundAudioProgress.setMax(audioServiceBinder.getTotalAudioDuration());
                            // Update progressbar. Make the value 10 times to show more clear UI change.
                            backgroundAudioProgress.setProgress(audioServiceBinder.getCurrentAudioPosition());

                            if(audioServiceBinder.getComplete()){
                                backgroundAudioProgress.setVisibility(ProgressBar.INVISIBLE);
                            }else{
                                backgroundAudioProgress.setVisibility(ProgressBar.VISIBLE);
                            }
                        }
                    }
                }
            };
        }
    }


    public class TimerClass extends CountDownTimer {

        TimerClass(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        //Method ini berjalan saat waktu/timer berubah
        @Override
        public void onTick(long millisUntilFinished) {
            //Kenfigurasi Format Waktu yang digunakan
            String waktuTo = String.format("%02d:%02d:%02d",
                    TimeUnit.MILLISECONDS.toHours(millisUntilFinished),
                    TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) -
                            TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
                    TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                            TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)));

            //Menampilkannya pada TexView
            waktu.setText(waktuTo);
        }

        @Override
        public void onFinish() {
            ///Berjalan saat waktu telah selesai atau berhenti
            Toast.makeText(Activity1.this, "Waktu Telah Berakhir", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void addDummyData() {
        //Dummy Data
        mengerjakanSoal = new ArrayList<>();

        final String alphabet = "ABCDEN";
        final int N = alphabet.length();

        for(int l=0; l<=bankSoal.size()-1; l++) {
            Random r = new Random();
            String x = String.valueOf(alphabet.charAt(r.nextInt(N)));
            //mengerjakanSoal.add(new MengerjakanSoal(String.valueOf(l+1), x,y));
        }

    }

    @Override
    public void onBackPressed() {

        if (drawer.isDrawerOpen(GravityCompat.END)) {
            drawer.closeDrawer(GravityCompat.END);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);

        super.onCreateOptionsMenu(menu);

        this.menu = menu;

        MenuItem menuPlay = menu.findItem(R.id.action_play);
        MenuItem menuPause = menu.findItem(R.id.action_pause);

        menuPlay.setVisible(false);
        menuPause.setVisible(false);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.action_drawer) {
            if (drawer.isDrawerOpen(GravityCompat.END)) {
                drawer.closeDrawer(GravityCompat.END);
            } else
                drawer.openDrawer(GravityCompat.END);
        }

        final MenuItem menuPlay = menu.findItem(R.id.action_play);
        final MenuItem menuPause = menu.findItem(R.id.action_pause);

        if (item.getItemId() == R.id.action_play) {
            menuPlay.setVisible(false);
            menuPause.setVisible(true);

            if( menuPause.isVisible() && !audioFileUrl.equals("") ) {

                // Set web audio file url
                audioServiceBinder.setAudioFileUrl(audioFileUrl);

                // Web audio is a stream audio.
                audioServiceBinder.setStreamAudio(true);

                // Set application context.
                audioServiceBinder.setContext(getApplicationContext());

                // Initialize audio progress bar updater Handler object.
                createAudioProgressbarUpdater();
                audioServiceBinder.setAudioProgressUpdateHandler(audioProgressUpdateHandler);

                // Start audio in background service.
                audioServiceBinder.startAudio();

                backgroundAudioProgress.setVisibility(ProgressBar.VISIBLE);
            }else{
                menuPlay.setVisible(true);
                menuPause.setVisible(false);
            }

        }else if (item.getItemId() == R.id.action_pause) {
            menuPlay.setVisible(true);
            menuPause.setVisible(false);

            audioServiceBinder.pauseAudio();

            backgroundAudioProgress.setVisibility(ProgressBar.INVISIBLE);
        }


        return super.onOptionsItemSelected(item);
    }

    private void setUpViewPager(ViewPager viewpage,ArrayList<BankSoal> dataBankSoal){
        adapter = new viewPageAdapter(getSupportFragmentManager(),getApplicationContext());

        for(int l=0; l<=dataBankSoal.size()-1; l++) {
            adapter.addFragmentPage(String.valueOf(l+1),dataBankSoal );
        }
        //We Need Fragment class now

        viewpage.setAdapter(adapter);

    }


    @Override
    protected void onDestroy() {
        // Unbound background audio service when activity is destroyed.
        unBoundAudioService();
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onStop() {
        super.onStop();  // Always call the superclass method first

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    public class viewPageAdapter extends FragmentPagerAdapter {
        private final List<String> myPageTitle = new ArrayList<>();
        ArrayList<BankSoal> dataBankSoalPages = new ArrayList<>();
        Context ctx;

        public viewPageAdapter(FragmentManager manager, Context applicationContext){
            super(manager);
            this.ctx = applicationContext;
        }

        public void addFragmentPage(String Title, ArrayList<BankSoal> dataBankSoal){
            myPageTitle.add(Title);
            dataBankSoalPages.addAll( dataBankSoal );
        }

        @Override
        public Fragment getItem(int position) {
            return new Page().newInstance(dataBankSoalPages.get(position));
        }

        @Override
        public int getCount() {
            return myPageTitle.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return myPageTitle.get(position);
        }

        @Override
        public int getItemPosition(Object object) {
            // POSITION_NONE makes it possible to reload the PagerAdapter
            return POSITION_NONE;
        }


    }

    public static class Page extends Fragment {
        Context ctx;
        TextView tanya1;
        String no_soal, tanya_soal, tanya_soal_audio, jawab_a, jawab_b, jawab_c, jawab_d, jawab_e;

        public Fragment newInstance(BankSoal dataBankSoal) {
            Page f = new Page();

            // Supply num input as an argument.
            Bundle args = new Bundle();
            args.putString("no_soal", dataBankSoal.no_soal());
            args.putString("tanya_soal", dataBankSoal.tanya_soal());
            args.putString("tanya_soal_audio", dataBankSoal.tanya_soal_audio());
            args.putString("jawab_a", dataBankSoal.jawab_a());
            args.putString("jawab_b", dataBankSoal.jawab_b());
            args.putString("jawab_c", dataBankSoal.jawab_c());
            args.putString("jawab_d", dataBankSoal.jawab_d());
            args.putString("jawab_e", dataBankSoal.jawab_e());
            f.setArguments(args);

            return f;
        }


        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            no_soal = getArguments().getString("no_soal");
            tanya_soal = getArguments().getString("tanya_soal");
            tanya_soal_audio = getArguments().getString("tanya_soal_audio");
            //tanya_gambar = getArguments().getString("tanya_gambar");
            //tanya_soal2 = getArguments().getString("tanya_soal2");
            jawab_a = getArguments().getString("jawab_a");
            jawab_b = getArguments().getString("jawab_b");
            jawab_c = getArguments().getString("jawab_c");
            jawab_d = getArguments().getString("jawab_d");
            jawab_e = getArguments().getString("jawab_e");

            ctx = getContext();


        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View PageTree = inflater.inflate(R.layout.page, container, false);

            //audioFileUrl = "http://www.dev2qa.com/demo/media/test.mp3";

            tanya1 = PageTree.findViewById(R.id.txtSoal);
            //ImageView tanya1_gambar = PageTree.findViewById(R.id.tanya1_gambar);
            //TextView tanya2 = PageTree.findViewById(R.id.tanya2);

            RadioButton jawabA = PageTree.findViewById(R.id.rb_A);
            RadioButton jawabB = PageTree.findViewById(R.id.rb_B);
            RadioButton jawabC = PageTree.findViewById(R.id.rb_C);
            RadioButton jawabD = PageTree.findViewById(R.id.rb_D);
            RadioButton jawabE = PageTree.findViewById(R.id.rb_E);

            jawabA.setText(jawab_a);
            jawabB.setText(jawab_b);
            jawabC.setText(jawab_c);
            jawabD.setText(jawab_d);
            jawabE.setText(jawab_e);



            if(!tanya_soal_audio.equals("") )
            audioFileUrl = tanya_soal_audio;

            //RecyclerView recyclerView = PageTree.findViewById(R.id.jawaban);
            //String[] data = {jawab_a,jawab_b,jawab_c,jawab_d,jawab_e};

            //final LinearLayoutManager layoutManager = new  LinearLayoutManager(getContext());
            //layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            //recyclerView.setLayoutManager(layoutManager);

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N){
                Spanned spanned = Html.fromHtml(tanya_soal, new ImageGetter(getResources(),tanya1), null);
                tanya1.setText(spanned);
                //tanya1.setText(Html.fromHtml(tanya_soal, new ImageGetter(), null));
            }else {
                Spanned spanned = Html.fromHtml(tanya_soal, Html.FROM_HTML_MODE_COMPACT, new ImageGetter(getResources(), tanya1), null);
                tanya1.setText(spanned);
                //tanya1.setText(Html.fromHtml(tanya_soal, Html.FROM_HTML_MODE_COMPACT, new ImageGetter(), null));
            }

            RadioGroup jawabGroup = PageTree.findViewById(R.id.rgAnswer);

            jawabGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    // find which radio button is selected

                }

            });


            final CheckBox ragu_ragu = PageTree.findViewById(R.id.btn_belum_terjawab);
            final ImageView prev = PageTree.findViewById(R.id.btnPrev);
            final ImageView next = PageTree.findViewById(R.id.btnNext);

            showPrevNext(prev,next,pages.getCurrentItem());
            prev.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    pages.setCurrentItem(pages.getCurrentItem()-1, true); //getItem(-1) for previous
                }
            });
            next.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    pages.setCurrentItem(pages.getCurrentItem()+1, true); //getItem(-1) for previous
                }
            });


            pages.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    nomor.setText( String.valueOf(tabs.getSelectedTabPosition()+1) );

                    showPrevNext(prev,next,pages.getCurrentItem());
                /*

                String tanya_soal_audio = bankSoal.get(position).tanya_soal_audio();

                final MenuItem menuPlay = menu.findItem(R.id.action_play);
                final MenuItem menuPause = menu.findItem(R.id.action_pause);

                if(!tanya_soal_audio.isEmpty() ) {
                    menuPlay.setVisible(true);
                    menuPause.setVisible(false);
                }else{
                    menuPlay.setVisible(false);
                    menuPause.setVisible(false);
                }

                if(audioServiceBinder.isStreamAudio()) {
                    audioServiceBinder.stopAudio();
                }

                */

                //Toast.makeText(getActivity().getApplicationContext(), position, Toast.LENGTH_SHORT).show();

                }

                @Override
                public void onPageScrollStateChanged(int state) {
                }
            });

            return PageTree;
        }

        private void showPrevNext(ImageView prev, ImageView next, int currentItem) {
            if( currentItem == 0 ){
                prev.setVisibility(View.GONE);
                next.setVisibility(View.VISIBLE);
            }else if( currentItem == bankSoal.size()-1 ){
                prev.setVisibility(View.VISIBLE);
                next.setVisibility(View.GONE);
            }else{
                prev.setVisibility(View.VISIBLE);
                next.setVisibility(View.VISIBLE);
            }
        }

    }

}
